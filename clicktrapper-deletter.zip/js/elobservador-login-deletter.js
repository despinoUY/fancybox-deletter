if (!localStorage.getItem('CMSFrontendIdUsuario')){
  localStorage.setItem('CMSFrontendIdUsuario','0');
}
