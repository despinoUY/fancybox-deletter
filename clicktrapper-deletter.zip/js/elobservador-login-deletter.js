console.log('hola');
document.getElementById('desktop').setAttribute('data-tipo_de_nota','free');